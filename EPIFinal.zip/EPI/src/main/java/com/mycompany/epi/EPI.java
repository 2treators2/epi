/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.epi;

/**
 *
 * @author sebag
 */
public class EPI {

    public static void main(String[] args) {
       new VentanaDatos();
       
    }
}
